package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.TrabajoPorOperario;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryTrabajoPorOperario;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class IServiceTrabajoPorOperarioImpl implements IServiceTrabajoPorOperario{
    @Autowired
    private IRepositoryTrabajoPorOperario repositoryTrabajoPorOperario;

    @Override
    public List<TrabajoPorOperario> Listar() {
        return null;
    }

    @Override
    public TrabajoPorOperario ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(TrabajoPorOperario Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
