package com.example.ServiPeru.ServiPeru.Repository;


import com.example.ServiPeru.ServiPeru.Model.TrabajoPorOperario;

import java.util.List;

public interface IRepositoryTrabajoPorOperario {
    List<TrabajoPorOperario> Listar();
    TrabajoPorOperario ListarPorCodigo(int cod);
    int crear(TrabajoPorOperario Objeto);
    int Modificar(TrabajoPorOperario Objeto);
    int Eliminar(int cod);
}
