package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Contrato;

import java.util.List;

public interface IServiceContratos {
    List<Contrato> Listar();
    Contrato ListarPorCodigo(int cod);
    int Modificar(Contrato Objeto);
    int Eliminar(int cod);
}
