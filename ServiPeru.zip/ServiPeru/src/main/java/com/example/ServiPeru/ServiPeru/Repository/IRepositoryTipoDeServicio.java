package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.CategoriaMaterial;
import com.example.ServiPeru.ServiPeru.Model.TipoDeServicio;

import java.util.List;

public interface IRepositoryTipoDeServicio {
    List<TipoDeServicio> Listar();
    TipoDeServicio ListarPorCodigo(int cod);
    int crear(TipoDeServicio Objeto);
    int Modificar(TipoDeServicio Objeto);
    int Eliminar(int cod);
}
