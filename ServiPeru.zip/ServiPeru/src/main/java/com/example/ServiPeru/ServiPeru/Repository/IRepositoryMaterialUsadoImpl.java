package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.MaterialUsado;

import java.util.List;

public class IRepositoryMaterialUsadoImpl implements IRepositoryMaterialUsado{
    @Override
    public List<MaterialUsado> Listar() {
        return null;
    }

    @Override
    public MaterialUsado ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int crear(MaterialUsado Objeto) {
        return 0;
    }

    @Override
    public int Modificar(MaterialUsado Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
