package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Contrato;

import java.util.List;

public class IRepositoryContratosImpl implements IRepositoryContratos{
    @Override
    public List<Contrato> Listar() {
        return null;
    }

    @Override
    public Contrato ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int crear(Contrato Objeto) {
        return 0;
    }

    @Override
    public int Modificar(Contrato Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
