package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Usuario;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryUsuario;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class IServiceUsuarioImpl implements IServiceUsuario{

    @Autowired
    private IRepositoryUsuario repositoryUsuario;

    @Override
    public List<Usuario> Listar() {
        return null;
    }

    @Override
    public Usuario ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(Usuario Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
