package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.ServicioPorRealizar;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryServiciosPorRealizar;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class IServiceServicioPorRealizarImpl implements IServiceServicioPorRealizar{
    @Autowired
    private IRepositoryServiciosPorRealizar repositoryServiciosPorRealizar;

    @Override
    public List<ServicioPorRealizar> Listar() {
        return null;
    }

    @Override
    public ServicioPorRealizar ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(ServicioPorRealizar Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
