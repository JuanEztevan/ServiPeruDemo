package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.CategoriaMaterial;

import java.util.List;

public class IRepositoryCategoriasMaterialImpl implements IRepositoryCategoriasMaterial {
    @Override
    public List<CategoriaMaterial> Listar() {
        return null;
    }

    @Override
    public CategoriaMaterial ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int crear(CategoriaMaterial Objeto) {
        return 0;
    }

    @Override
    public int Modificar(CategoriaMaterial Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
