package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Servicio;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryServicio;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class IServiceServicioImpl implements IServiceServicio{
    @Autowired
    private IRepositoryServicio repositoryServicio;

    @Override
    public List<Servicio> Listar() {
        return null;
    }

    @Override
    public Servicio ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(Servicio Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
