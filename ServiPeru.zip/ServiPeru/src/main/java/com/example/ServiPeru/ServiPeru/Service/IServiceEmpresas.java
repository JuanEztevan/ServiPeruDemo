package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Empresas;

import java.util.List;

public interface IServiceEmpresas {
    List<Empresas> Listar();
    Empresas ListarPorCodigo(int cod);
    int Modificar(Empresas Objeto);
    int Eliminar(int cod);
}
