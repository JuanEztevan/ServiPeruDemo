package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.CategoriaMaterial;

import java.util.List;

public interface IRepositoryCategoriasMaterial {
    List<CategoriaMaterial> Listar();
    CategoriaMaterial ListarPorCodigo(int cod);
    int crear(CategoriaMaterial Objeto);
    int Modificar(CategoriaMaterial Objeto);
    int Eliminar(int cod);
}
