package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.CategoriaMaterial;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryCategoriasMaterial;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class IServiceCategoriasMaterialImpl implements IServiceCategoriasMaterial{
    @Autowired
    private IRepositoryCategoriasMaterial repositoryCategoriasMaterial;

    @Override
    public List<CategoriaMaterial> Listar() {
        return null;
    }

    @Override
    public CategoriaMaterial ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(CategoriaMaterial Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
