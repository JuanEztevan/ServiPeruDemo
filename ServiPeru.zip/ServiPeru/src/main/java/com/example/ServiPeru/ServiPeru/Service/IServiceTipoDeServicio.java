package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.TipoDeServicio;

import java.util.List;

public interface IServiceTipoDeServicio {
    List<TipoDeServicio> Listar();
    TipoDeServicio ListarPorCodigo(int cod);
    int Modificar(TipoDeServicio Objeto);
    int Eliminar(int cod);
}
