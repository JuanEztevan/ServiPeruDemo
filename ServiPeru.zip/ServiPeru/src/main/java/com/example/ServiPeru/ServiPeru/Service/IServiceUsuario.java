package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Usuario;

import java.util.List;

public interface IServiceUsuario {
    List<Usuario> Listar();
    Usuario ListarPorCodigo(int cod);
    int Modificar(Usuario Objeto);
    int Eliminar(int cod);
}
