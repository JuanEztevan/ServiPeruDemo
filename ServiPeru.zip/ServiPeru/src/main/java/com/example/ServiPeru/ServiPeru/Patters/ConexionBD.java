package com.example.ServiPeru.ServiPeru.Patters;

public class ConexionBD {
}
