package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Servicio;

import java.util.List;

public class IRepositoryServicioImpl implements IRepositoryServicio{
    @Override
    public List<Servicio> Listar() {
        return null;
    }

    @Override
    public Servicio ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int crear(Servicio Objeto) {
        return 0;
    }

    @Override
    public int Modificar(Servicio Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
