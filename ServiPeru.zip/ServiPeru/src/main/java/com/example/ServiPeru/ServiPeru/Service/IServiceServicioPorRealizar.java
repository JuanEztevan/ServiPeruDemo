package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.ServicioPorRealizar;

import java.util.List;

public interface IServiceServicioPorRealizar {
    List<ServicioPorRealizar> Listar();
    ServicioPorRealizar ListarPorCodigo(int cod);
    int Modificar(ServicioPorRealizar Objeto);
    int Eliminar(int cod);
}
