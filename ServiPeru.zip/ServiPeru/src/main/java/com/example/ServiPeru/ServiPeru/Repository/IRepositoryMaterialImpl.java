package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Materiales;

import java.util.List;

public class IRepositoryMaterialImpl implements IRepositoryMaterial{
    @Override
    public List<Materiales> Listar() {
        return null;
    }

    @Override
    public Materiales ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int crear(Materiales Objeto) {
        return 0;
    }

    @Override
    public int Modificar(Materiales Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
