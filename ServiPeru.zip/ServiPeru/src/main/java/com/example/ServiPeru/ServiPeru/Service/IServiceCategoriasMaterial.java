package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.CategoriaMaterial;

import java.util.List;

public interface IServiceCategoriasMaterial {
    List<CategoriaMaterial> Listar();
    CategoriaMaterial ListarPorCodigo(int cod);
    int Modificar(CategoriaMaterial Objeto);
    int Eliminar(int cod);
}
