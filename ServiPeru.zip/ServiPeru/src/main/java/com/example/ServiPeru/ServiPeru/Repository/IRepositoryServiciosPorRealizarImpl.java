package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.ServicioPorRealizar;

import java.util.List;

public class IRepositoryServiciosPorRealizarImpl implements IRepositoryServiciosPorRealizar{
    @Override
    public List<ServicioPorRealizar> Listar() {
        return null;
    }

    @Override
    public ServicioPorRealizar ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int crear(ServicioPorRealizar Objeto) {
        return 0;
    }

    @Override
    public int Modificar(ServicioPorRealizar Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
