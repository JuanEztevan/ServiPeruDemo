package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Operarios;

import java.util.List;

public interface IServiceOperarios {
    List<Operarios> Listar();
    Operarios ListarPorCodigo(int cod);
    int Modificar(Operarios Objeto);
    int Eliminar(int cod);
}
