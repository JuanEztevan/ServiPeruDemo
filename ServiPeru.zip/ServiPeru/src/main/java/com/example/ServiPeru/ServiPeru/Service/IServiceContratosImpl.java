package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Contrato;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryContratos;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.PrimitiveIterator;

public class IServiceContratosImpl implements IServiceContratos{
    @Autowired
    private IRepositoryContratos repositoryContratos;

    @Override
    public List<Contrato> Listar() {
        return null;
    }

    @Override
    public Contrato ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(Contrato Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
