package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Servicio;

import java.util.List;

public interface IServiceServicio {
    List<Servicio> Listar();
    Servicio ListarPorCodigo(int cod);
    int Modificar(Servicio Objeto);
    int Eliminar(int cod);
}
