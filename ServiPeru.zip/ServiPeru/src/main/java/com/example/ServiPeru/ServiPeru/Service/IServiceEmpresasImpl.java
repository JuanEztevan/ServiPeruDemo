package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Empresas;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryEmpresas;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class IServiceEmpresasImpl implements IServiceEmpresas{
    @Autowired
    private IRepositoryEmpresas repositoryEmpresas;

    @Override
    public List<Empresas> Listar() {
        return null;
    }

    @Override
    public Empresas ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(Empresas Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
