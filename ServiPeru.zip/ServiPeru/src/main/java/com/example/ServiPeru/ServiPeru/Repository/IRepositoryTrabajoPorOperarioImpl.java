package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.TrabajoPorOperario;

import java.util.List;

public class IRepositoryTrabajoPorOperarioImpl implements IRepositoryTrabajoPorOperario{
    @Override
    public List<TrabajoPorOperario> Listar() {
        return null;
    }

    @Override
    public TrabajoPorOperario ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int crear(TrabajoPorOperario Objeto) {
        return 0;
    }

    @Override
    public int Modificar(TrabajoPorOperario Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
