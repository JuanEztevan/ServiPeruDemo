package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Contrato;

import java.util.List;

public interface IRepositoryContratos {
    List<Contrato> Listar();
    Contrato ListarPorCodigo(int cod);
    int crear(Contrato Objeto);
    int Modificar(Contrato Objeto);
    int Eliminar(int cod);

}
