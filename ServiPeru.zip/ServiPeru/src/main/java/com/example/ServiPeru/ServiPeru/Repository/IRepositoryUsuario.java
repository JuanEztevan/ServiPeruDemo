package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Usuario;

import java.util.List;

public interface IRepositoryUsuario {
    List<Usuario> Listar();
    Usuario ListarPorCodigo(int cod);
    int crear(Usuario Objeto);
    int Modificar(Usuario Objeto);
    int Eliminar(int cod);
}
