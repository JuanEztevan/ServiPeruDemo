package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Materiales;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryMaterial;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class IServiceMaterialImpl implements IServiceMaterial{
    @Autowired
    private IRepositoryMaterial repositoryMaterial;

    @Override
    public List<Materiales> Listar() {
        return null;
    }

    @Override
    public Materiales ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(Materiales Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
