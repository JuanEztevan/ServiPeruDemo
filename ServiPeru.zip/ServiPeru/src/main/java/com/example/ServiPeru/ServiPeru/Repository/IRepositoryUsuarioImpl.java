package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Usuario;

import java.util.List;

public class IRepositoryUsuarioImpl implements IRepositoryUsuario{
    @Override
    public List<Usuario> Listar() {
        return null;
    }

    @Override
    public Usuario ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int crear(Usuario Objeto) {
        return 0;
    }

    @Override
    public int Modificar(Usuario Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
