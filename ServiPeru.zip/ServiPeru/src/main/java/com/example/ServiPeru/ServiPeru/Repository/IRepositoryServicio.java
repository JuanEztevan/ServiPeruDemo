package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Servicio;

import java.util.List;

public interface IRepositoryServicio {
    List<Servicio> Listar();
    Servicio ListarPorCodigo(int cod);
    int crear(Servicio Objeto);
    int Modificar(Servicio Objeto);
    int Eliminar(int cod);
}
