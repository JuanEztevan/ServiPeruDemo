package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.MaterialUsado;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryMaterialUsado;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class IServiceMaterialUsadoImpl implements IServiceMaterialUsado{
    @Autowired
    private IRepositoryMaterialUsado repositoryMaterialUsado;

    @Override
    public List<MaterialUsado> Listar() {
        return null;
    }

    @Override
    public MaterialUsado ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(MaterialUsado Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
