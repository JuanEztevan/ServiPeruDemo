package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Empresas;

import java.util.List;

public interface IRepositoryEmpresas {
    List<Empresas> Listar();
    Empresas ListarPorCodigo(int cod);
    int crear(Empresas Objeto);
    int Modificar(Empresas Objeto);
    int Eliminar(int cod);
}
