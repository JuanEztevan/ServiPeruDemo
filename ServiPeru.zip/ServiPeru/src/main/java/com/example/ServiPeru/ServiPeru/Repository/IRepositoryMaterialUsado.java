package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.CategoriaMaterial;
import com.example.ServiPeru.ServiPeru.Model.MaterialUsado;

import java.util.List;

public interface IRepositoryMaterialUsado {
    List<MaterialUsado> Listar();
    MaterialUsado ListarPorCodigo(int cod);
    int crear(MaterialUsado Objeto);
    int Modificar(MaterialUsado Objeto);
    int Eliminar(int cod);
}
