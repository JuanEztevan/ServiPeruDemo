package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Operarios;

import java.util.List;

public interface IRepositoryOperarios {
    List<Operarios> Listar();
    Operarios ListarPorCodigo(int cod);
    int crear(Operarios Objeto);
    int Modificar(Operarios Objeto);
    int Eliminar(int cod);
}
