package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.TipoDeServicio;

import java.util.List;

public class IRepositoryTipoDeServicioImpl implements IRepositoryTipoDeServicio{
    @Override
    public List<TipoDeServicio> Listar() {
        return null;
    }

    @Override
    public TipoDeServicio ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int crear(TipoDeServicio Objeto) {
        return 0;
    }

    @Override
    public int Modificar(TipoDeServicio Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
