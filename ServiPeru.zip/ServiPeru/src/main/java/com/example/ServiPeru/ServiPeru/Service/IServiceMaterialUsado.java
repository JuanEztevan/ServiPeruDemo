package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.MaterialUsado;

import java.util.List;

public interface IServiceMaterialUsado {
    List<MaterialUsado> Listar();
    MaterialUsado ListarPorCodigo(int cod);
    int Modificar(MaterialUsado Objeto);
    int Eliminar(int cod);
}
