package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.Materiales;

import java.util.List;

public interface IRepositoryMaterial {
    List<Materiales> Listar();
    Materiales ListarPorCodigo(int cod);
    int crear(Materiales Objeto);
    int Modificar(Materiales Objeto);
    int Eliminar(int cod);
}
