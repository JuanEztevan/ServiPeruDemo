package com.example.ServiPeru.ServiPeru.Service;

import com.example.ServiPeru.ServiPeru.Model.Operarios;
import com.example.ServiPeru.ServiPeru.Repository.IRepositoryOperarios;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class IServiceOperariosImpl implements IServiceOperarios{
    @Autowired
    private IRepositoryOperarios repositoryOperarios;

    @Override
    public List<Operarios> Listar() {
        return null;
    }

    @Override
    public Operarios ListarPorCodigo(int cod) {
        return null;
    }

    @Override
    public int Modificar(Operarios Objeto) {
        return 0;
    }

    @Override
    public int Eliminar(int cod) {
        return 0;
    }
}
