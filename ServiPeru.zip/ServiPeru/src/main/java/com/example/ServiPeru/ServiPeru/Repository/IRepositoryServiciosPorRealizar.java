package com.example.ServiPeru.ServiPeru.Repository;

import com.example.ServiPeru.ServiPeru.Model.ServicioPorRealizar;

import java.util.List;

public interface IRepositoryServiciosPorRealizar {
    List<ServicioPorRealizar> Listar();
    ServicioPorRealizar ListarPorCodigo(int cod);
    int crear(ServicioPorRealizar Objeto);
    int Modificar(ServicioPorRealizar Objeto);
    int Eliminar(int cod);
}
