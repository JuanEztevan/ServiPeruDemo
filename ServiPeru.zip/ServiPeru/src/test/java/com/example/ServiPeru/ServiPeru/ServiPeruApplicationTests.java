package com.example.ServiPeru.ServiPeru;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiPeruApplicationTests {

	@Test
	void contextLoads() {
	}

}
